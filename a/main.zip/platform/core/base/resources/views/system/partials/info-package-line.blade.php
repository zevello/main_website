{{ $item['name'] }} : <span class="label ld-version-tag">{{ $item['version'] }}</span>
