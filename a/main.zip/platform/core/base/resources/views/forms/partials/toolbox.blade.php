<div class="tools">
    <a
        class="collapse"
        data-bs-toggle="tooltip"
        data-bs-original-title="Collapse/Expand"
        href="#"
        title="Collapse/Expand"
    ></a>
    <a
        class="fullscreen"
        data-bs-toggle="tooltip"
        data-bs-original-title="Full screen"
        href="#"
        title="Full screen"
    > </a>
</div>
