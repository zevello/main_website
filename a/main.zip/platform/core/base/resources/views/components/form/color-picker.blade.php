<x-core::form.text-input {{ $attributes->merge(['type' => 'color', 'class' => 'form-control-color']) }} />
