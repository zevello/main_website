<div {{ $attributes->merge(['class' => 'mb-3 position-relative']) }}>
    {{ $slot }}
</div>
