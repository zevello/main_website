<x-core::layouts.base>
    @yield('page')
</x-core::layouts.base>
