@if (!empty($data))
    <div
        class="meta-box-sortables"
        id="{{ $context }}-sortables"
    >
        {!! $data !!}
    </div>
@endif
