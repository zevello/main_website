<i class="fa fa-plus"></i> {{ trans('core/base::forms.create') }}
