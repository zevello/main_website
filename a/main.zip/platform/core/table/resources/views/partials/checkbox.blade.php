<div class="text-start">
    <div class="checkbox checkbox-primary table-checkbox">
        <input
            class="checkboxes"
            name="id[]"
            type="checkbox"
            value="{{ $id }}"
        />
    </div>
</div>
