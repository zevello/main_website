<div {{ $attributes->merge(['class' => 'form-group mb-3']) }}>
    {{ $slot }}
</div>
